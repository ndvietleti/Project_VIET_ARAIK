# traffic-proc-tools

Some tools for traffic analysis.

gg1_function.py - function file, used together with gg1_parallel.py. Uses simpy library.
gg1_parallel.py - main G/G/1 queue simulation script
